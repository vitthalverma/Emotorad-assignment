const Duration scratchInterval = Duration(hours: 1);
